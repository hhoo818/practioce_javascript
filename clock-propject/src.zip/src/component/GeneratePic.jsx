import PropTypes from "prop-types";
const GeneratePic = ()=>{
    const connectServer = async (props) => {
        try {
          // サーバーにリクエストを送信
          const response = await fetch("https://165e-34-125-152-209.ngrok-free.app", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              prompt:
                props.prompt,
              negative_prompt:
               props.negative_prompt,
               height: props.height || 768,
              width: props.width || 512,
              guidance_scale: 8,
              num_inference_steps: 44,
              seed: -1,
            }),
          });
      
          // レスポンスのステータスを確認
          if (!response.ok) {
            throw new Error("サーバーエラー: " + response.status);
          }
      
          // Blob形式で画像を受け取る
          const blob = await response.blob();
      
          // BlobからURLを作成
          const imgURL = URL.createObjectURL(blob);
      
          // HTMLの<img>要素に画像を設定
          const imgElement = document.createElement("img");
          imgElement.src = imgURL;
          imgElement.alt = "Generated Image";
          imgElement.style.maxWidth = "100%"; // 表示サイズを制限
          imgElement.style.border = "1px solid #ccc"; // デザインのための枠線を追加
      
          // 画像を表示するためのHTML要素に追加
          const outputDiv = document.getElementById("output");
          outputDiv.innerHTML = ""; // 古い内容をクリア
          outputDiv.appendChild(imgElement);
        } catch (error) {
          console.error("エラーが発生しました:", error);
      
          // エラーメッセージを表示
          const outputDiv = document.getElementById("output");
          outputDiv.innerHTML = `<p style="color:red;">画像の生成に失敗しました: ${error.message}</p>`;
        }
      };
}
GeneratePic.PropTypes={
    prompt:PropTypes.string,
    negative_prompt:PropTypes.string,
    height:PropTypes.number,
    width:PropTypes.number,
}
